import express from "express";

const router = express.Router();
//
// router.post("/create", createUser)

export default router;
